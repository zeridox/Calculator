$(document).ready(function(){
    $('button').click(function(){
        var clickit = 0;
        var val = $(this).val();
        arr =[];
        arr.push(val);
        // var left="";
        // var right="";

        // if (val == "a" || val == "s" || val == "m" || val == "d"){
        //     var clickit=clickit+1;
        // };
        // console.log(clickit);
        return arr;
    });
    $('#calc').append(arr);
    // function add(a,b){
        
        
    //     sum = a+b;
    //     return sum;
    // };
    // var adding = add(3,5);
    // console.log(adding);
});