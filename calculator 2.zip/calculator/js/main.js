$(document).ready(function(){

    function add(a,b){
        sum = a+b;
        return sum;
    };
    function multiply(a,b){
        product = a*b;
        return product;
    };
    function divide(a,b){
        dividen = a/b;
        return dividen;
    };
    function subtract(a,b){
        sub = a-b;
        return sub;
    };

    var operator = '';
    var next = false;
    var right = [];
    var left = [];
    // left is supposed to join after e is called 

    $('.b').click(function(){
        if(next == false){
            let val = $(this).val();
            $('#calc').append(val);
            left.push(val);
        }else if(next==true){
            let val = $(this).val();
            $('#ulate').append(val);
            right.push(val);
        };
        
    });

    var m = $('#button-m');
    var d = $('#button-d');
    var a = $('#button-a');
    var s = $('#button-s');

    m.click(function(){
        operator = "m";
        var mult= $('#button-m').val();
        $('#op').text(mult);
        next = true;
    });
    d.click(function(){
        operator = "d";
        var div= $('#button-d').val();
        $('#op').text(div);
        next = true;
    });
    a.click(function(){
        operator = "a";
        var addd= $('#button-a').val();
        $('#op').text(addd);
        next = true;
    });
    s.click(function(){
        operator = "s";
        var subb= $('#button-s').val();
        $('#op').text(subb);
        next = true;
    });

    $('#button-e').click(function(){
        left.join('');
        if(operator == "m"){
            var a= left.join('');
            var b= right.join('');
            $('#op').text('');
            multiply(a,b);
            $('#calc').text(product);
            $('#ulate').text('');
            left = [];
            right = [];
        };
    });


}); 